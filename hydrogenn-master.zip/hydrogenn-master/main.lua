activity.newActivity("home",{activity.getIntent()})
activity.finish()